# __init__.py
from .game_scene import GameScene
from .menu_scene import MenuScene
